<?php
/**
 * Plugin Name: Shortcode Plugin
 * Plugin URI: https://www.shortcodeplugin.com
 * Description: Display content using a shortcode to insert in a page or post
 * Version: 0.1
 * Text Domain: shortcode-plugin
 * Author: Prachi garg
 * Author URI: https://www.prachi.com
 */
 
 function shortcode_plugin($atts) {
	$Content = "<style>\r\n";
	$Content .= "h3.demoClass {\r\n";
	$Content .= "color: #26b158;\r\n";
	$Content .= "}\r\n";
	$Content .= "</style>\r\n";
	$Content .= '<h3 class="demoClass">Check it out!</h3>';
	 
    return $Content;
}

add_shortcode('shortcode-plugin', 'shortcode_plugin');